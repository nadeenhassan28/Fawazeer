package com.example.fawazyr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FawazyrApplicationTests {

	@Test
	void contextLoads() {
	}

}
